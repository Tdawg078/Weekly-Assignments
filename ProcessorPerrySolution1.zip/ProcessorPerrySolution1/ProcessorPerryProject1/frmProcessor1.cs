﻿using System.Windows.Forms;

namespace ProcessorPerryProject1
{
    internal class frmProcessor : Form
    {
    }
}