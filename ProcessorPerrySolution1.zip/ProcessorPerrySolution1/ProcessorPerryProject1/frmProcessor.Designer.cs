﻿namespace ProcessorPerryProject1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInput = new System.Windows.Forms.TextBox();
            this.txtSentences = new System.Windows.Forms.TextBox();
            this.txtWords = new System.Windows.Forms.TextBox();
            this.txtUniqueWords = new System.Windows.Forms.TextBox();
            this.txtCharacterCount = new System.Windows.Forms.TextBox();
            this.txtAvgWordLength = new System.Windows.Forms.TextBox();
            this.FirstWords = new System.Windows.Forms.ListBox();
            this.grpOptions = new System.Windows.Forms.GroupBox();
            this.rdoWordPairs = new System.Windows.Forms.RadioButton();
            this.rdoUniqueWords = new System.Windows.Forms.RadioButton();
            this.rdoAllWords = new System.Windows.Forms.RadioButton();
            this.checkShowFrequency = new System.Windows.Forms.CheckBox();
            this.btnProcess = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtInput
            // 
            this.txtInput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInput.Location = new System.Drawing.Point(374, 59);
            this.txtInput.Multiline = true;
            this.txtInput.Name = "txtInput";
            this.txtInput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtInput.Size = new System.Drawing.Size(609, 31);
            this.txtInput.TabIndex = 0;
            // 
            // txtSentences
            // 
            this.txtSentences.Location = new System.Drawing.Point(374, 138);
            this.txtSentences.Name = "txtSentences";
            this.txtSentences.ReadOnly = true;
            this.txtSentences.Size = new System.Drawing.Size(300, 31);
            this.txtSentences.TabIndex = 1;
            // 
            // txtWords
            // 
            this.txtWords.Location = new System.Drawing.Point(374, 211);
            this.txtWords.Name = "txtWords";
            this.txtWords.ReadOnly = true;
            this.txtWords.Size = new System.Drawing.Size(300, 31);
            this.txtWords.TabIndex = 2;
            // 
            // txtUniqueWords
            // 
            this.txtUniqueWords.Location = new System.Drawing.Point(374, 284);
            this.txtUniqueWords.Name = "txtUniqueWords";
            this.txtUniqueWords.ReadOnly = true;
            this.txtUniqueWords.Size = new System.Drawing.Size(300, 31);
            this.txtUniqueWords.TabIndex = 3;
            // 
            // txtCharacterCount
            // 
            this.txtCharacterCount.Location = new System.Drawing.Point(374, 371);
            this.txtCharacterCount.Name = "txtCharacterCount";
            this.txtCharacterCount.ReadOnly = true;
            this.txtCharacterCount.Size = new System.Drawing.Size(300, 31);
            this.txtCharacterCount.TabIndex = 4;
            // 
            // txtAvgWordLength
            // 
            this.txtAvgWordLength.Location = new System.Drawing.Point(365, 464);
            this.txtAvgWordLength.Name = "txtAvgWordLength";
            this.txtAvgWordLength.ReadOnly = true;
            this.txtAvgWordLength.Size = new System.Drawing.Size(300, 31);
            this.txtAvgWordLength.TabIndex = 5;
            // 
            // FirstWords
            // 
            this.FirstWords.FormattingEnabled = true;
            this.FirstWords.ItemHeight = 25;
            this.FirstWords.Location = new System.Drawing.Point(45, 464);
            this.FirstWords.Name = "FirstWords";
            this.FirstWords.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.FirstWords.Size = new System.Drawing.Size(194, 79);
            this.FirstWords.TabIndex = 6;
            // 
            // grpOptions
            // 
            this.grpOptions.Controls.Add(this.rdoWordPairs);
            this.grpOptions.Controls.Add(this.rdoUniqueWords);
            this.grpOptions.Controls.Add(this.rdoAllWords);
            this.grpOptions.Location = new System.Drawing.Point(326, 561);
            this.grpOptions.Name = "grpOptions";
            this.grpOptions.Size = new System.Drawing.Size(233, 164);
            this.grpOptions.TabIndex = 7;
            this.grpOptions.TabStop = false;
            this.grpOptions.Text = "groupBox1";
            // 
            // rdoWordPairs
            // 
            this.rdoWordPairs.AutoSize = true;
            this.rdoWordPairs.Location = new System.Drawing.Point(6, 100);
            this.rdoWordPairs.Name = "rdoWordPairs";
            this.rdoWordPairs.Size = new System.Drawing.Size(196, 29);
            this.rdoWordPairs.TabIndex = 2;
            this.rdoWordPairs.TabStop = true;
            this.rdoWordPairs.Text = "Two-Word Pairs";
            this.rdoWordPairs.UseVisualStyleBackColor = true;
            // 
            // rdoUniqueWords
            // 
            this.rdoUniqueWords.AutoSize = true;
            this.rdoUniqueWords.Location = new System.Drawing.Point(6, 65);
            this.rdoUniqueWords.Name = "rdoUniqueWords";
            this.rdoUniqueWords.Size = new System.Drawing.Size(179, 29);
            this.rdoUniqueWords.TabIndex = 1;
            this.rdoUniqueWords.TabStop = true;
            this.rdoUniqueWords.Text = "Unique Words";
            this.rdoUniqueWords.UseVisualStyleBackColor = true;
            // 
            // rdoAllWords
            // 
            this.rdoAllWords.AutoSize = true;
            this.rdoAllWords.Location = new System.Drawing.Point(6, 30);
            this.rdoAllWords.Name = "rdoAllWords";
            this.rdoAllWords.Size = new System.Drawing.Size(135, 29);
            this.rdoAllWords.TabIndex = 0;
            this.rdoAllWords.TabStop = true;
            this.rdoAllWords.Text = "All Words";
            this.rdoAllWords.UseVisualStyleBackColor = true;
            // 
            // checkShowFrequency
            // 
            this.checkShowFrequency.AutoSize = true;
            this.checkShowFrequency.Location = new System.Drawing.Point(674, 591);
            this.checkShowFrequency.Name = "checkShowFrequency";
            this.checkShowFrequency.Size = new System.Drawing.Size(205, 29);
            this.checkShowFrequency.TabIndex = 8;
            this.checkShowFrequency.Text = "Show Frequency";
            this.checkShowFrequency.UseVisualStyleBackColor = true;
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(31, 790);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(124, 40);
            this.btnProcess.TabIndex = 9;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(177, 790);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(110, 40);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(326, 790);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(130, 40);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1171, 898);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.checkShowFrequency);
            this.Controls.Add(this.grpOptions);
            this.Controls.Add(this.FirstWords);
            this.Controls.Add(this.txtAvgWordLength);
            this.Controls.Add(this.txtCharacterCount);
            this.Controls.Add(this.txtUniqueWords);
            this.Controls.Add(this.txtWords);
            this.Controls.Add(this.txtSentences);
            this.Controls.Add(this.txtInput);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Text Processor";
            this.grpOptions.ResumeLayout(false);
            this.grpOptions.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.TextBox txtSentences;
        private System.Windows.Forms.TextBox txtWords;
        private System.Windows.Forms.TextBox txtUniqueWords;
        private System.Windows.Forms.TextBox txtCharacterCount;
        private System.Windows.Forms.TextBox txtAvgWordLength;
        private System.Windows.Forms.ListBox FirstWords;
        private System.Windows.Forms.GroupBox grpOptions;
        private System.Windows.Forms.RadioButton rdoUniqueWords;
        private System.Windows.Forms.RadioButton rdoAllWords;
        private System.Windows.Forms.RadioButton rdoWordPairs;
        private System.Windows.Forms.CheckBox checkShowFrequency;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}

