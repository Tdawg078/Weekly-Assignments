﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ProcessorPerryProject1
{
    public partial class MainForm : Form
    {
        public MainForm() => InitializeComponent();


        private void btnProcess_Click(object sender, EventArgs e)
        {
            // Get input text
            string input = txtInput.Text.Trim();

            // Validation: Ensure input is not empty
            if (string.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show("Please enter text before processing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Processing
            int sentenceCount = CountSentences(input);
            List<string> words = ExtractWords(input);
            int wordCount = words.Count;
            int uniqueWordCount = words.Distinct(StringComparer.OrdinalIgnoreCase).Count();
            int characterCount = input.Length;
            double avgWordLength = wordCount > 0 ? words.Average(w => w.Length) : 0;

            // Display results
            txtSentences.Text = sentenceCount.ToString();
            txtWords.Text = wordCount.ToString();
            txtUniqueWords.Text = uniqueWordCount.ToString();
            txtCharacterCount.Text = characterCount.ToString();
            txtAvgWordLength.Text = avgWordLength.ToString("F2");

            // Display words based on selection
            FirstWords.Items.Clear();
            if (rdoAllWords.Checked)
            {
                FirstWords.Items.AddRange(words.ToArray());
            }
            else if (rdoUniqueWords.Checked)
            {
                var uniqueWords = words.GroupBy(w => w, StringComparer.OrdinalIgnoreCase)
                                       .Select(g => checkShowFrequency.Checked ? $"{g.Key} ({g.Count()})" : g.Key)
                                       .ToArray();
                FirstWords.Items.AddRange(uniqueWords);
            }
            else if (rdoWordPairs.Checked)
            {
                var pairs = GetWordPairs(words);
                FirstWords.Items.AddRange(pairs.ToArray());
            }
        }

        private int CountSentences(string text)
        {
            return text.Count(c => c == '.' || c == '?' || c == '!');
        }

        private List<string> ExtractWords(string text)
        {
            var words = text.Split(new char[] { ' ', '\n', '\r', '\t', ',', '.', '!', '?', ';', ':' },
                                   StringSplitOptions.RemoveEmptyEntries);
            return words.Where(w => !string.IsNullOrWhiteSpace(w)).ToList();
        }

        private List<string> GetWordPairs(List<string> words)
        {
            var pairs = new List<string>();
            for (int i = 0; i < words.Count - 1; i++)
            {
                pairs.Add($"{words[i]} {words[i + 1]}");
            }
            return pairs;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtInput.Clear();
            txtSentences.Clear();
            txtWords.Clear();
            txtUniqueWords.Clear();
            txtCharacterCount.Clear();
            txtAvgWordLength.Clear();
            FirstWords.Items.Clear();
            rdoAllWords.Checked = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void rdoUniqueWords_CheckedChanged(object sender, EventArgs e)
        {
            checkShowFrequency.Enabled = rdoUniqueWords.Checked;
        }
    }
}

