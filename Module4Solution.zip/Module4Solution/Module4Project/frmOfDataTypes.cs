﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Module4Project
{
    public partial class frmofDataTypes : Form
    {
        public frmofDataTypes()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnPow_Click(object sender, EventArgs e)
        {
            {
                double baseNum = 2, exponent = 3;
                double result = Math.Pow(baseNum, exponent);
                lblDisplay.Text = $"{baseNum} ^ {exponent} = {result}";
            }
        }

        private string GetV()
        {
            return v;
        }

        private void BtnByte_Click(object sender, EventArgs e, string v, string v)
        {
            // Byte Addition (+)
        
        {
            byte leftOperand = 10, rightOperand = 5;
            byte result = (byte)(leftOperand + rightOperand);
                string v = $"{leftOperand} + {rightOperand} = {result}";
                lblDisplay.Text = v;



        private void btnShort_Click(object sender, EventArgs e)
        {
             
        {
            short leftOperand = 20, rightOperand = 8;
            short result = (short)(leftOperand - rightOperand);
            lblDisplay.Text = $"{leftOperand} - {rightOperand} = {result}";
        }
    }

        private void btnInt_Click(object sender, EventArgs e)
        {
            {
                int leftOperand = 10, rightOperand = 3;
                int result = leftOperand / rightOperand;
                lblDisplay.Text = $"{leftOperand} / {rightOperand} = {result}";
            }
        }

        private void btnLong_Click(object sender, EventArgs e)
        {
            {
                long leftOperand = 100, rightOperand = 30;
                long result = leftOperand % rightOperand;
                lblDisplay.Text = $"{leftOperand} % {rightOperand} = {result}";
            }
        }

        private void btnFloat_Click(object sender, EventArgs e)
        {
            {
                float leftOperand = 10.5f, rightOperand = 3.2f;
                float result = leftOperand % rightOperand;
                lblDisplay.Text = $"{leftOperand} % {rightOperand} = {result:F7}";
            }
        }

        private void btnDouble_Click(object sender, EventArgs e)
        {
            {
                double leftOperand = 10.0, rightOperand = 3.0;
                double result = leftOperand / rightOperand;
                lblDisplay.Text = $"{leftOperand} / {rightOperand} = {result:F15}";
            }
        }

        private void btnDecimal_Click(object sender, EventArgs e)
        {
            {
                decimal leftOperand = 10.5m, rightOperand = 3.2m;
                decimal result = leftOperand * rightOperand;
                lblDisplay.Text = $"{leftOperand} * {rightOperand} = {result}";
            }
        }

        private void btnRound_Click(object sender, EventArgs e)
        {
            {
                double number = 5.6789;
                int precision = 2;
                double result = Math.Round(number, precision);
                lblDisplay.Text = $"Rounded {number} to {precision} decimal places: {result}";
            }
        }

        private void btnSqrt_Click(object sender, EventArgs e)
        {
            {
                double number = 16;
                double result = Math.Sqrt(number);
                lblDisplay.Text = $"Square root of {number} is {result}";
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            {
                lblDisplay.Text = "";
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            {
                Application.Exit();
            }
        }
    }
    }

