﻿namespace Perry_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblTheDenominator = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbllTheDominator = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.BtnRed1 = new System.Windows.Forms.Button();
            this.BtnPurple1 = new System.Windows.Forms.Button();
            this.BtnOrange1 = new System.Windows.Forms.Button();
            this.BtnGreen1 = new System.Windows.Forms.Button();
            this.BtnLightBlue1 = new System.Windows.Forms.Button();
            this.BtnYellow1 = new System.Windows.Forms.Button();
            this.BtnGray1 = new System.Windows.Forms.Button();
            this.BtnBlack1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.BtnBlue1 = new System.Windows.Forms.Button();
            this.BtnYellow2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(376, 230);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            // 
            // lblTheDenominator
            // 
            this.lblTheDenominator.AutoSize = true;
            this.lblTheDenominator.BackColor = System.Drawing.Color.White;
            this.lblTheDenominator.Location = new System.Drawing.Point(178, 230);
            this.lblTheDenominator.Name = "lblTheDenominator";
            this.lblTheDenominator.Size = new System.Drawing.Size(0, 13);
            this.lblTheDenominator.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(178, 255);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(178, 255);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 3;
            // 
            // lbllTheDominator
            // 
            this.lbllTheDominator.Location = new System.Drawing.Point(178, 255);
            this.lbllTheDominator.Name = "lbllTheDominator";
            this.lbllTheDominator.Size = new System.Drawing.Size(0, 0);
            this.lbllTheDominator.TabIndex = 4;
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(352, 0);
            this.button3.TabIndex = 5;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // BtnRed1
            // 
            this.BtnRed1.BackColor = System.Drawing.Color.Red;
            this.BtnRed1.Location = new System.Drawing.Point(139, 44);
            this.BtnRed1.Name = "BtnRed1";
            this.BtnRed1.Size = new System.Drawing.Size(75, 75);
            this.BtnRed1.TabIndex = 6;
            this.BtnRed1.UseVisualStyleBackColor = false;
            this.BtnRed1.Click += new System.EventHandler(this.BtnRed1_Click);
            // 
            // BtnPurple1
            // 
            this.BtnPurple1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnPurple1.Location = new System.Drawing.Point(256, 42);
            this.BtnPurple1.Name = "BtnPurple1";
            this.BtnPurple1.Size = new System.Drawing.Size(75, 75);
            this.BtnPurple1.TabIndex = 7;
            this.BtnPurple1.UseVisualStyleBackColor = false;
            // 
            // BtnOrange1
            // 
            this.BtnOrange1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.BtnOrange1.Location = new System.Drawing.Point(12, 125);
            this.BtnOrange1.Name = "BtnOrange1";
            this.BtnOrange1.Size = new System.Drawing.Size(75, 75);
            this.BtnOrange1.TabIndex = 8;
            this.BtnOrange1.UseVisualStyleBackColor = false;
            // 
            // BtnGreen1
            // 
            this.BtnGreen1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.BtnGreen1.Location = new System.Drawing.Point(154, 125);
            this.BtnGreen1.Name = "BtnGreen1";
            this.BtnGreen1.Size = new System.Drawing.Size(75, 75);
            this.BtnGreen1.TabIndex = 9;
            this.BtnGreen1.UseVisualStyleBackColor = false;
            // 
            // BtnLightBlue1
            // 
            this.BtnLightBlue1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnLightBlue1.Location = new System.Drawing.Point(256, 125);
            this.BtnLightBlue1.Name = "BtnLightBlue1";
            this.BtnLightBlue1.Size = new System.Drawing.Size(75, 75);
            this.BtnLightBlue1.TabIndex = 10;
            this.BtnLightBlue1.UseVisualStyleBackColor = false;
            // 
            // BtnYellow1
            // 
            this.BtnYellow1.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnYellow1.ForeColor = System.Drawing.Color.Black;
            this.BtnYellow1.Location = new System.Drawing.Point(0, 0);
            this.BtnYellow1.Name = "BtnYellow1";
            this.BtnYellow1.Size = new System.Drawing.Size(352, 0);
            this.BtnYellow1.TabIndex = 11;
            this.BtnYellow1.UseVisualStyleBackColor = true;
            this.BtnYellow1.Click += new System.EventHandler(this.BtnYellow1_Click);
            // 
            // BtnGray1
            // 
            this.BtnGray1.BackColor = System.Drawing.Color.DarkGray;
            this.BtnGray1.Location = new System.Drawing.Point(152, 223);
            this.BtnGray1.Name = "BtnGray1";
            this.BtnGray1.Size = new System.Drawing.Size(75, 75);
            this.BtnGray1.TabIndex = 12;
            this.BtnGray1.UseVisualStyleBackColor = false;
            // 
            // BtnBlack1
            // 
            this.BtnBlack1.BackColor = System.Drawing.Color.Black;
            this.BtnBlack1.Location = new System.Drawing.Point(265, 230);
            this.BtnBlack1.Name = "BtnBlack1";
            this.BtnBlack1.Size = new System.Drawing.Size(75, 75);
            this.BtnBlack1.TabIndex = 13;
            this.BtnBlack1.UseVisualStyleBackColor = false;
            this.BtnBlack1.Click += new System.EventHandler(this.button11_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(149, 280);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 14;
            // 
            // BtnBlue1
            // 
            this.BtnBlue1.BackColor = System.Drawing.Color.Blue;
            this.BtnBlue1.Location = new System.Drawing.Point(12, 42);
            this.BtnBlue1.Name = "BtnBlue1";
            this.BtnBlue1.Size = new System.Drawing.Size(75, 75);
            this.BtnBlue1.TabIndex = 16;
            this.BtnBlue1.UseVisualStyleBackColor = false;
            this.BtnBlue1.Click += new System.EventHandler(this.BtnBlue1_Click);
            // 
            // BtnYellow2
            // 
            this.BtnYellow2.BackColor = System.Drawing.Color.Yellow;
            this.BtnYellow2.Location = new System.Drawing.Point(12, 225);
            this.BtnYellow2.Name = "BtnYellow2";
            this.BtnYellow2.Size = new System.Drawing.Size(75, 75);
            this.BtnYellow2.TabIndex = 17;
            this.BtnYellow2.UseVisualStyleBackColor = false;
            this.BtnYellow2.Click += new System.EventHandler(this.button4_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(22, 318);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 75);
            this.button4.TabIndex = 19;
            this.button4.Text = "1";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(131, 323);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 75);
            this.button5.TabIndex = 20;
            this.button5.Text = "2";
            this.button5.UseMnemonic = false;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(245, 323);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 75);
            this.button6.TabIndex = 21;
            this.button6.Text = "3";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(22, 399);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 75);
            this.button7.TabIndex = 22;
            this.button7.Text = "4";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(131, 399);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 75);
            this.button8.TabIndex = 23;
            this.button8.Text = "5";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(245, 399);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 75);
            this.button9.TabIndex = 24;
            this.button9.Text = "6";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(176, 291);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 25;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(22, 463);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 75);
            this.button10.TabIndex = 26;
            this.button10.Text = "7";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(184, 299);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(192, 307);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 28;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(131, 463);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 75);
            this.button11.TabIndex = 29;
            this.button11.Text = "8";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(245, 455);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 75);
            this.button12.TabIndex = 30;
            this.button12.Text = "9";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(12, 544);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(150, 50);
            this.button13.TabIndex = 31;
            this.button13.Text = "&Clear";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(195, 544);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(150, 50);
            this.button14.TabIndex = 32;
            this.button14.Text = "E&xit";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(352, 594);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.BtnYellow2);
            this.Controls.Add(this.BtnBlue1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.BtnBlack1);
            this.Controls.Add(this.BtnGray1);
            this.Controls.Add(this.BtnYellow1);
            this.Controls.Add(this.BtnLightBlue1);
            this.Controls.Add(this.BtnGreen1);
            this.Controls.Add(this.BtnOrange1);
            this.Controls.Add(this.BtnPurple1);
            this.Controls.Add(this.BtnRed1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.lbllTheDominator);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTheDenominator);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTheDominator;
        private System.Windows.Forms.Button BtnRed;
        private System.Windows.Forms.Button BtnBlue;
        private System.Windows.Forms.Button BtnPink;
        private System.Windows.Forms.Button BtnYellow;
        private System.Windows.Forms.Button BtnGreen;
        private System.Windows.Forms.Button BtnBrown;
        private System.Windows.Forms.Button BtnLightBlue;
        private System.Windows.Forms.Button BtnOrange;
        private System.Windows.Forms.Button BtnPurple;
        private System.Windows.Forms.Button BtnDigit1;
        private System.Windows.Forms.Button BtnDigit2;
        private System.Windows.Forms.Button BtnDigit3;
        private System.Windows.Forms.Button BtnDigit4;
        private System.Windows.Forms.Button BtnDIgit5;
        private System.Windows.Forms.Button BtnDigit6;
        private System.Windows.Forms.Button BtnDigit7;
        private System.Windows.Forms.Button BtnDigit8;
        private System.Windows.Forms.Button BtnDigit9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTheDenominator;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbllTheDominator;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button BtnRed1;
        private System.Windows.Forms.Button BtnPurple1;
        private System.Windows.Forms.Button BtnOrange1;
        private System.Windows.Forms.Button BtnGreen1;
        private System.Windows.Forms.Button BtnLightBlue1;
        private System.Windows.Forms.Button BtnYellow1;
        private System.Windows.Forms.Button BtnGray1;
        private System.Windows.Forms.Button BtnBlack1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BtnBlue1;
        private System.Windows.Forms.Button BtnYellow2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
    }
}

