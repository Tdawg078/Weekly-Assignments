﻿using System;
using System.Text;

namespace PerryProjectApp
{
    partial class PerryApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblConvertFrom1 = new System.Windows.Forms.Label();
            this.lblBase1 = new System.Windows.Forms.Label();
            this.txtConvertFrom1 = new System.Windows.Forms.TextBox();
            this.txtBase1 = new System.Windows.Forms.TextBox();
            this.btnProcess1 = new System.Windows.Forms.Button();
            this.btnBinary1 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnOctal1 = new System.Windows.Forms.Button();
            this.btnBase61 = new System.Windows.Forms.Button();
            this.btnBase91 = new System.Windows.Forms.Button();
            this.btnClear1 = new System.Windows.Forms.Button();
            this.btnExit1 = new System.Windows.Forms.Button();
            this.ConvertDecimalToBase1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblConvertFrom1
            // 
            this.lblConvertFrom1.AutoSize = true;
            this.lblConvertFrom1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConvertFrom1.Location = new System.Drawing.Point(12, 46);
            this.lblConvertFrom1.Name = "lblConvertFrom1";
            this.lblConvertFrom1.Size = new System.Drawing.Size(308, 42);
            this.lblConvertFrom1.TabIndex = 0;
            this.lblConvertFrom1.Text = "\"Enter a Decimal\"";
            // 
            // lblBase1
            // 
            this.lblBase1.AutoSize = true;
            this.lblBase1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBase1.Location = new System.Drawing.Point(12, 111);
            this.lblBase1.Name = "lblBase1";
            this.lblBase1.Size = new System.Drawing.Size(338, 42);
            this.lblBase1.TabIndex = 1;
            this.lblBase1.Text = "\"Enter Base (2-16)\"";
            this.lblBase1.Click += new System.EventHandler(this.lblBase1_Click);
            // 
            // txtConvertFrom1
            // 
            this.txtConvertFrom1.Location = new System.Drawing.Point(375, 57);
            this.txtConvertFrom1.Name = "txtConvertFrom1";
            this.txtConvertFrom1.Size = new System.Drawing.Size(200, 31);
            this.txtConvertFrom1.TabIndex = 2;
            // 
            // txtBase1
            // 
            this.txtBase1.Location = new System.Drawing.Point(375, 122);
            this.txtBase1.Name = "txtBase1";
            this.txtBase1.Size = new System.Drawing.Size(200, 31);
            this.txtBase1.TabIndex = 3;
            // 
            // btnProcess1
            // 
            this.btnProcess1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProcess1.Location = new System.Drawing.Point(-8, 223);
            this.btnProcess1.Name = "btnProcess1";
            this.btnProcess1.Size = new System.Drawing.Size(167, 65);
            this.btnProcess1.TabIndex = 4;
            this.btnProcess1.Text = "&Process";
            this.btnProcess1.UseVisualStyleBackColor = true;
            // 
            // btnBinary1
            // 
            this.btnBinary1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBinary1.Location = new System.Drawing.Point(165, 223);
            this.btnBinary1.Name = "btnBinary1";
            this.btnBinary1.Size = new System.Drawing.Size(167, 65);
            this.btnBinary1.TabIndex = 5;
            this.btnBinary1.Text = "&Binary";
            this.btnBinary1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnBinary1.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(338, 223);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(167, 65);
            this.button1.TabIndex = 6;
            this.button1.Text = "&Hex";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnOctal1
            // 
            this.btnOctal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOctal1.Location = new System.Drawing.Point(511, 223);
            this.btnOctal1.Name = "btnOctal1";
            this.btnOctal1.Size = new System.Drawing.Size(158, 65);
            this.btnOctal1.TabIndex = 7;
            this.btnOctal1.Text = "&Octal";
            this.btnOctal1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnOctal1.UseVisualStyleBackColor = true;
            // 
            // btnBase61
            // 
            this.btnBase61.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBase61.Location = new System.Drawing.Point(-8, 294);
            this.btnBase61.Name = "btnBase61";
            this.btnBase61.Size = new System.Drawing.Size(167, 65);
            this.btnBase61.TabIndex = 8;
            this.btnBase61.Text = "&Base 6";
            this.btnBase61.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnBase61.UseVisualStyleBackColor = true;
            // 
            // btnBase91
            // 
            this.btnBase91.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBase91.Location = new System.Drawing.Point(165, 294);
            this.btnBase91.Name = "btnBase91";
            this.btnBase91.Size = new System.Drawing.Size(167, 65);
            this.btnBase91.TabIndex = 9;
            this.btnBase91.Text = "&Base9";
            this.btnBase91.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnBase91.UseVisualStyleBackColor = true;
            // 
            // btnClear1
            // 
            this.btnClear1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear1.Location = new System.Drawing.Point(19, 455);
            this.btnClear1.Name = "btnClear1";
            this.btnClear1.Size = new System.Drawing.Size(167, 65);
            this.btnClear1.TabIndex = 10;
            this.btnClear1.Text = "Clear";
            this.btnClear1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnClear1.UseMnemonic = false;
            this.btnClear1.UseVisualStyleBackColor = true;
            this.btnClear1.Click += new System.EventHandler(this.btnClear1_Click);
            // 
            // btnExit1
            // 
            this.btnExit1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit1.Location = new System.Drawing.Point(274, 455);
            this.btnExit1.Name = "btnExit1";
            this.btnExit1.Size = new System.Drawing.Size(167, 65);
            this.btnExit1.TabIndex = 11;
            this.btnExit1.Text = "Exit";
            this.btnExit1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnExit1.UseMnemonic = false;
            this.btnExit1.UseVisualStyleBackColor = true;
            // 
            // ConvertDecimalToBase1
            // 
            this.ConvertDecimalToBase1.AutoSize = true;
            this.ConvertDecimalToBase1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConvertDecimalToBase1.Location = new System.Drawing.Point(173, 563);
            this.ConvertDecimalToBase1.Name = "ConvertDecimalToBase1";
            this.ConvertDecimalToBase1.Size = new System.Drawing.Size(147, 42);
            this.ConvertDecimalToBase1.TabIndex = 12;
            this.ConvertDecimalToBase1.Text = "(Empty)";
            // 
            // PerryApp
            // 
            this.ClientSize = new System.Drawing.Size(786, 656);
            this.Controls.Add(this.ConvertDecimalToBase1);
            this.Controls.Add(this.btnExit1);
            this.Controls.Add(this.btnClear1);
            this.Controls.Add(this.btnBase91);
            this.Controls.Add(this.btnBase61);
            this.Controls.Add(this.btnOctal1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnBinary1);
            this.Controls.Add(this.btnProcess1);
            this.Controls.Add(this.txtBase1);
            this.Controls.Add(this.txtConvertFrom1);
            this.Controls.Add(this.lblBase1);
            this.Controls.Add(this.lblConvertFrom1);
            this.Name = "PerryApp";
            this.Text = "PerryApp1";
            this.Load += new System.EventHandler(this.PerryApp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void txtBase_TextChanged(object sender, EventArgs e) => throw new NotImplementedException();
        // Conversion logic to any base between 2 and 16
        



        private string GetBaseChar(int remainder)
        {
            throw new NotImplementedException();
        }
        #endregion

        private System.Windows.Forms.Label lblConvertFrom;
        private System.Windows.Forms.TextBox txtConvertFrom;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.TextBox txtBase;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.Button btnBinary;
        private System.Windows.Forms.Button btnHex;
        private System.Windows.Forms.Button btnOctal;
        private System.Windows.Forms.Button btnBase6;
        private System.Windows.Forms.Button btnBase9;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Label lblConvertFrom1;
        private System.Windows.Forms.Label lblBase1;
        private System.Windows.Forms.TextBox txtConvertFrom1;
        private System.Windows.Forms.TextBox txtBase1;
        private System.Windows.Forms.Button btnProcess1;
        private System.Windows.Forms.Button btnBinary1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnOctal1;
        private System.Windows.Forms.Button btnBase61;
        private System.Windows.Forms.Button btnBase91;
        private System.Windows.Forms.Button btnClear1;
        private System.Windows.Forms.Button btnExit1;
        private System.Windows.Forms.Label ConvertDecimalToBase1;
    }
}