﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PerryProjectApp
{
    public partial class PerryApp : Form
    {
        private object baseValue;
        private string message;

        public PerryApp()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            lblMessage.Text = ""; // Clear previous messages

            if (int.TryParse(txtConvertFrom.Text, out int number) &&
                int.TryParse(txtBase.Text, out int baseValue))
            {
                if (baseValue < 2 || baseValue > 16)
                {
                    lblMessage.Text = "Error: Base must be between 2 and 16.";
                    return;
                }
                lblMessage.Text = ConvertToBase(number, baseValue);
            }
            else
            {
                lblMessage.Text = "Error: Please enter valid integer values.";
            }
        }

        // ✅ Convert a base-10 number to any base between 2 and 16
        private string ConvertToBase(int number, int baseValue)
        {
            if (number == 0) return baseValue + "x0"; // Edge case for 0

            string result = "";
            string digits = "0123456789ABCDEF";  // Digits for bases up to 16

            while (number > 0)
            {
                result = digits[number % baseValue] + result; // Build the result string
                number /= baseValue; // Reduce number for next iteration
            }

            // Add the correct prefix (e.g., "5x" for base 5, "0x" for hex)
            return (baseValue == 16 ? "0x" : baseValue + "x") + result;
        }

        private void btnBinary_Click(object sender, EventArgs e)
        {
            
        {
            lblMessage.Text = ""; // Clear previous messages

            if (int.TryParse(txtConvertFrom.Text, out int number) &&
                int.TryParse(txtBase.Text, out int baseValue))
            {
                if (baseValue < 2 || baseValue > 16)
                {
                    lblMessage.Text = "Error: Base must be between 2 and 16.";
                    return;
                }
                lblMessage.Text = ConvertToBase(number, baseValue);
            }
            else
            {
                lblMessage.Text = "Error: Please enter valid integer values.";
            }
        }

    }

        private void btnHex_Click(object sender, EventArgs e)
        {
            
        {
            lblMessage.Text = ""; // Clear previous messages

            if (int.TryParse(txtConvertFrom.Text, out int number) &&
                int.TryParse(txtBase.Text, out int baseValue))
            {
                if (baseValue < 2 || baseValue > 16)
                {
                    lblMessage.Text = "Error: Base must be between 2 and 16.";
                    return;
                }
                lblMessage.Text = ConvertToBase(number, baseValue);
            }
            else
            {
                lblMessage.Text = "Error: Please enter valid integer values.";
            }
        }

    }

        private void btnOctal_Click(object sender, EventArgs e)
        {
           
        {
            lblMessage.Text = ""; // Clear previous messages

            if (int.TryParse(txtConvertFrom.Text, out int number) &&
                int.TryParse(txtBase.Text, out int baseValue))
            {
                if (baseValue < 2 || baseValue > 16)
                {
                    lblMessage.Text = "Error: Base must be between 2 and 16.";
                    return;
                }
                lblMessage.Text = ConvertToBase(number, baseValue);
            }
            else
            {
                lblMessage.Text = "Error: Please enter valid integer values.";
            }
        }

    }

        private void btnBase6_Click(object sender, EventArgs e)
        {
            
        {
            lblMessage.Text = ""; // Clear previous messages

            if (int.TryParse(txtConvertFrom.Text, out int number) &&
                int.TryParse(txtBase.Text, out int baseValue))
            {
                if (baseValue < 2 || baseValue > 16)
                {
                    lblMessage.Text = "Error: Base must be between 2 and 16.";
                    return;
                }
                lblMessage.Text = ConvertToBase(number, baseValue);
            }
            else
            {
                lblMessage.Text = "Error: Please enter valid integer values.";
            }
        }

    }

        private void btnBase9_Click(object sender, EventArgs e)
        {
            
        {
            lblMessage.Text = ""; // Clear previous messages

            if (int.TryParse(txtConvertFrom.Text, out int number) &&
                int.TryParse(txtBase.Text, out int baseValue))
            {
                if (baseValue < 2 || baseValue > 16)
                {
                    lblMessage.Text = "Error: Base must be between 2 and 16.";
                    return;
                }
                lblMessage.Text = ConvertToBase(number, baseValue);
            }
            else
            {
                lblMessage.Text = "Error: Please enter valid integer values.";
            }
        }

    }

        private void btnClear_Click(object sender, EventArgs e)
        {
            
        {
            txtConvertFrom.Clear();
            txtBase.Clear();
            lblMessage.Text = "";
        }

    }

        private void btnExit_Click(object sender, EventArgs e)
        {
            
        {
            Application.Exit();
        }

    }

        private object GetBaseValue()
        {
            return baseValue;
        }


        private string ConvertFrom_Base;

        public PerryApp(string convertFrom_Base)
        {
            ConvertFrom_Base = convertFrom_Base;
        }

        private void lblBase1_Click(object sender, EventArgs e)
        {

        }

        private void PerryApp_Load(object sender, EventArgs e)
        {

        }

        private void btnClear1_Click(object sender, EventArgs e)
        {
            
            
         
        }
    }
    }











