﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week2_Perry_Project
{
    [DebuggerDisplay("{" + nameof(GetDebuggerDisplay) + "(),nq}")]
    public partial class Form1 : Form
    {
        private object txtInput;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }
        private void btnWipe_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = ""; // Clear the display label
        }

        private class lblDisplay
        {
            public static string Text { get; internal set; }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            private void btnSave_Click(object sender, EventArgs e) =>
            // Copy the text from the input textbox to the display label
            lblDisplay.Text = txtInput.Text;

        private string GetDebuggerDisplay()
        {
            return ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            private void btnCancel_Click(object sender, EventArgs e)
        {
            txtInput.Text = ""; // Clear the input textbox
        }

        private void button4_Click(object sender, EventArgs e)
        {
            private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the application
        }

    }
}
}
} 
        {

}

  
        {

}

}

    }
}
}
