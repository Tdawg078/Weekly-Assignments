﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace CheckDigitsAppPerryProject
{
    /// <summary>
    /// Author: [Your Name]
    /// Class: frmCheckDigit
    /// Due Date: [Insert Due Date]
    /// </summary>
    public partial class frmCheckDigitsApp : Form
    {
        public frmCheckDigitsApp()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the application
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtAccountNumber.Text = "";
            txtConfirmAccount.Text = "";
            txtPaymentAmount.Text = "";
            lblMessageArea.Text = "";
            txtAccountNumber.Focus(); // Set focus to account number textbox
        }

        private bool IsValidAccount(string accountNumber)
        {
            // Ensure account number is 8 digits and numeric
            if (accountNumber.Length != 8 || !accountNumber.All(char.IsDigit))
            {
                return false;
            }

            // Simple check-digit algorithm
            int sum = 0;
            for (int i = 0; i < 7; i++)
            {
                sum += int.Parse(accountNumber[i].ToString());
            }

            int checkDigit = sum % 10;
            return checkDigit == int.Parse(accountNumber[7].ToString());
        }

        private bool ValidateInputs(out string errorMessage)
        {
            errorMessage = "";

            // Ensure all fields are filled
            if (string.IsNullOrWhiteSpace(txtAccountNumber.Text) ||
                string.IsNullOrWhiteSpace(txtConfirmAccount.Text) ||
                string.IsNullOrWhiteSpace(txtPaymentAmount.Text))
            {
                errorMessage = "All fields must be filled.";
                return false;
            }

            // Ensure account numbers are numeric
            if (!txtAccountNumber.Text.All(char.IsDigit) || !txtConfirmAccount.Text.All(char.IsDigit))
            {
                errorMessage = "Account numbers must be numeric.";
                return false;
            }

            // Ensure account numbers match
            if (txtAccountNumber.Text != txtConfirmAccount.Text)
            {
                errorMessage = "Account numbers do not match.";
                return false;
            }

            // Ensure payment amount is valid
            if (!decimal.TryParse(txtPaymentAmount.Text, out decimal payment) || payment <= 0)
            {
                errorMessage = "Invalid payment amount.";
                return false;
            }

            return true;
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            lblMessageArea.Text = ""; // Clear message area before processing

            // Validate inputs
            if (!ValidateInputs(out string errorMessage))
            {
                lblMessageArea.Text = errorMessage;
                return;
            }

            // Validate account number
            if (!IsValidAccount(txtAccountNumber.Text))
            {
                lblMessageArea.Text = "Invalid account number (failed check digit verification).";
                return;
            }

            // Validate payment amount format and convert to decimal
            if (!decimal.TryParse(txtPaymentAmount.Text, out decimal payment))
            {
                lblMessageArea.Text = "Invalid payment amount format.";
                return;
            }

            // Format the payment amount to currency
            string formattedPayment = payment.ToString("C");

            // Get the current date
            string currentDate = DateTime.Now.ToString("MMMM dd, yyyy");

            // Display the success message
            lblMessageArea.Text = $"A payment of {formattedPayment} was applied to account {txtAccountNumber.Text} on {currentDate}.";
        }
    }
}

