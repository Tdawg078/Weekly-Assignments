﻿

using System;
using System.Windows.Forms;

namespace PerryLab_Project
{

    private TextBox txtMessage;
    private Label lblLastMessage;

    public partial class Exam1LabTeletypeSimulation0621 : Form
    {
        public Exam1LabTeletypeSimulation0621()
        {
            InitializeComponent();
        }

        private void btnA_Click(object sender, EventArgs e) => txtMessage.Text += "A";
        private void btnB_Click(object sender, EventArgs e) => txtMessage.Text += "B";
        private void btnC_Click(object sender, EventArgs e) => txtMessage.Text += "C";
        private void btnD_Click(object sender, EventArgs e) => txtMessage.Text += "D";
        private void btnE_Click(object sender, EventArgs e) => txtMessage.Text += "E";
        private void btnF_Click(object sender, EventArgs e) => txtMessage.Text += "F";
        private void btnG_Click(object sender, EventArgs e) => txtMessage.Text += "G";
        private void btnH_Click(object sender, EventArgs e) => txtMessage.Text += "H";
        private void btnI_Click(object sender, EventArgs e) => txtMessage.Text += "I";
        private void btnJ_Click(object sender, EventArgs e) => txtMessage.Text += "J";
        private void btnK_Click(object sender, EventArgs e) => txtMessage.Text += "K";
        private void btnL_Click(object sender, EventArgs e) => txtMessage.Text += "L";
        private void btnM_Click(object sender, EventArgs e) => txtMessage.Text += "M";
        private void btnN_Click(object sender, EventArgs e) => txtMessage.Text += "N";
        private void btnO_Click(object sender, EventArgs e) => txtMessage.Text += "O";
        private void btnP_Click(object sender, EventArgs e) => txtMessage.Text += "P";
        private void btnQ_Click(object sender, EventArgs e) => txtMessage.Text += "Q";
        private void btnR_Click(object sender, EventArgs e) => txtMessage.Text += "R";
        private void btnS_Click(object sender, EventArgs e) => txtMessage.Text += "S";
        private void btnT_Click(object sender, EventArgs e) => txtMessage.Text += "T";
        private void btnU_Click(object sender, EventArgs e) => txtMessage.Text += "U";
        private void btnV_Click(object sender, EventArgs e) => txtMessage.Text += "V";
        private void btnW_Click(object sender, EventArgs e) => txtMessage.Text += "W";
        private void btnX_Click(object sender, EventArgs e) => txtMessage.Text += "X";
        private void btnY_Click(object sender, EventArgs e) => txtMessage.Text += "Y";
        private void btnZ_Click(object sender, EventArgs e) => txtMessage.Text += "Z";
        private void btn0_Click(object sender, EventArgs e) => txtMessage.Text += "0";
        private void btn1_Click(object sender, EventArgs e) => txtMessage.Text += "1";
        private void btn2_Click(object sender, EventArgs e) => txtMessage.Text += "2";
        private void btn3_Click(object sender, EventArgs e) => txtMessage.Text += "3";
        private void btn4_Click(object sender, EventArgs e) => txtMessage.Text += "4";
        private void btn5_Click(object sender, EventArgs e) => txtMessage.Text += "5";
        private void btn6_Click(object sender, EventArgs e) => txtMessage.Text += "6";
        private void btn7_Click(object sender, EventArgs e) => txtMessage.Text += "7";
        private void btn8_Click(object sender, EventArgs e) => txtMessage.Text += "8";
        private void btn9_Click(object sender, EventArgs e) => txtMessage.Text += "9";
        private void btnPeriod_Click(object sender, EventArgs e) => txtMessage.Text += ".";
        private void btnSpace_Click(object sender, EventArgs e) => txtMessage.Text += " ";
        private void btnClear_Click(object sender, EventArgs e) => txtMessage.Clear();
        private void btnSend_Click(object sender, EventArgs e)
        {
            lblLastMessage.Text = "Last Sent Message: " + txtMessage.Text;
            txtMessage.Clear();
        }
        private void btnExit_Click(object sender, EventArgs e) => Application.Exit();
    }
}
