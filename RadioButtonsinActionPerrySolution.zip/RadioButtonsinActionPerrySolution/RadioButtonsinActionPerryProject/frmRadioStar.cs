﻿using System;
using System.Windows.Forms;

namespace RadioButtonsinActionPerryProject
{
    public partial class frmRadioStar : Form
    {
        public frmRadioStar()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Radio Buttons in Action";
            this.BackColor = System.Drawing.Color.LightBlue;
        }

        private void frmRadioStar_Load(object sender, EventArgs e)
        {
            rdoAdd.Checked = true;
            chkVerbose.Checked = true;
            txtLeftOperand.BackColor = System.Drawing.Color.LightYellow;
            txtRightOperand.BackColor = System.Drawing.Color.LightYellow;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtLeftOperand.Text = "";
            txtRightOperand.Text = "";
            lblMessage.Text = "";
            rdoAdd.Checked = true;
            chkVerbose.Checked = true;
            txtLeftOperand.Focus();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            txtLeftOperand.Refresh();
            txtRightOperand.Refresh();

            if (string.IsNullOrWhiteSpace(txtLeftOperand.Text) || string.IsNullOrWhiteSpace(txtRightOperand.Text))
            {
                lblMessage.Text = "Error: Both operands must be entered.";
                return;
            }

            if (!int.TryParse(txtLeftOperand.Text.Trim(), out int leftOperand) || !int.TryParse(txtRightOperand.Text.Trim(), out int rightOperand))
            {
                lblMessage.Text = "Error: Please enter valid integers for both operands.";
                return;
            }

            if ((rdoDivide.Checked || rdoModulus.Checked) && rightOperand == 0)
            {
                lblMessage.Text = "Error: Cannot divide or use modulus by zero.";
                return;
            }
            if (rdoModulus.Checked && leftOperand < 0)
            {
                lblMessage.Text = "Error: Modulus operation cannot be performed on negative numbers.";
                return;
            }

            int result = 0;
            string operation = "";
            if (rdoAdd.Checked) { result = leftOperand + rightOperand; operation = "+"; }
            else if (rdoSubtract.Checked) { result = leftOperand - rightOperand; operation = "-"; }
            else if (rdoMultiply.Checked) { result = leftOperand * rightOperand; operation = "*"; }
            else if (rdoDivide.Checked) { result = leftOperand / rightOperand; operation = "/"; }
            else if (rdoModulus.Checked) { result = leftOperand % rightOperand; operation = "%"; }

            if (chkVerbose.Checked)
                lblMessage.Text = $"{leftOperand} {operation} {rightOperand} = {result}";
            else
                lblMessage.Text = $"The Answer is: {result}";
        }
    }
}

