﻿using System;

namespace RadioButtonsinActionPerryProject
{
    partial class frmRadioStar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLeftOperand = new System.Windows.Forms.Label();
            this.txtLeftOperand = new System.Windows.Forms.TextBox();
            this.lblRIghtOperand = new System.Windows.Forms.Label();
            this.txtRightOperand = new System.Windows.Forms.TextBox();
            this.grpOperations = new System.Windows.Forms.GroupBox();
            this.rdoModulus = new System.Windows.Forms.RadioButton();
            this.rdoDivide = new System.Windows.Forms.RadioButton();
            this.rdoMultiply = new System.Windows.Forms.RadioButton();
            this.rdoSubtract = new System.Windows.Forms.RadioButton();
            this.rdoAdd = new System.Windows.Forms.RadioButton();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.chkVerbose = new System.Windows.Forms.CheckBox();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpOperations.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblLeftOperand
            // 
            this.lblLeftOperand.AutoSize = true;
            this.lblLeftOperand.Location = new System.Drawing.Point(46, 49);
            this.lblLeftOperand.Name = "lblLeftOperand";
            this.lblLeftOperand.Size = new System.Drawing.Size(149, 25);
            this.lblLeftOperand.TabIndex = 0;
            this.lblLeftOperand.Text = "Left Operand: ";
            this.lblLeftOperand.Click += new System.EventHandler(this.lblLeftOperand_Click);
            // 
            // txtLeftOperand
            // 
            this.txtLeftOperand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtLeftOperand.ForeColor = System.Drawing.Color.White;
            this.txtLeftOperand.Location = new System.Drawing.Point(239, 49);
            this.txtLeftOperand.Name = "txtLeftOperand";
            this.txtLeftOperand.Size = new System.Drawing.Size(200, 31);
            this.txtLeftOperand.TabIndex = 0;
            // 
            // lblRIghtOperand
            // 
            this.lblRIghtOperand.AutoSize = true;
            this.lblRIghtOperand.Location = new System.Drawing.Point(46, 109);
            this.lblRIghtOperand.Name = "lblRIghtOperand";
            this.lblRIghtOperand.Size = new System.Drawing.Size(163, 25);
            this.lblRIghtOperand.TabIndex = 1;
            this.lblRIghtOperand.Text = "RIght Operand: ";
            // 
            // txtRightOperand
            // 
            this.txtRightOperand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtRightOperand.Location = new System.Drawing.Point(239, 109);
            this.txtRightOperand.Name = "txtRightOperand";
            this.txtRightOperand.Size = new System.Drawing.Size(200, 31);
            this.txtRightOperand.TabIndex = 1;
            // 
            // grpOperations
            // 
            this.grpOperations.Controls.Add(this.rdoModulus);
            this.grpOperations.Controls.Add(this.rdoDivide);
            this.grpOperations.Controls.Add(this.rdoMultiply);
            this.grpOperations.Controls.Add(this.rdoSubtract);
            this.grpOperations.Controls.Add(this.rdoAdd);
            this.grpOperations.Location = new System.Drawing.Point(239, 165);
            this.grpOperations.Name = "grpOperations";
            this.grpOperations.Size = new System.Drawing.Size(308, 208);
            this.grpOperations.TabIndex = 2;
            this.grpOperations.TabStop = false;
            this.grpOperations.Text = "Math Operations Available";
            // 
            // rdoModulus
            // 
            this.rdoModulus.AutoSize = true;
            this.rdoModulus.Location = new System.Drawing.Point(6, 173);
            this.rdoModulus.Name = "rdoModulus";
            this.rdoModulus.Size = new System.Drawing.Size(164, 29);
            this.rdoModulus.TabIndex = 4;
            this.rdoModulus.TabStop = true;
            this.rdoModulus.Text = "Modulus (%)";
            this.rdoModulus.UseVisualStyleBackColor = true;
            // 
            // rdoDivide
            // 
            this.rdoDivide.AutoSize = true;
            this.rdoDivide.Location = new System.Drawing.Point(6, 144);
            this.rdoDivide.Name = "rdoDivide";
            this.rdoDivide.Size = new System.Drawing.Size(129, 29);
            this.rdoDivide.TabIndex = 3;
            this.rdoDivide.TabStop = true;
            this.rdoDivide.Text = "Divide (/)";
            this.rdoDivide.UseVisualStyleBackColor = true;
            // 
            // rdoMultiply
            // 
            this.rdoMultiply.AutoSize = true;
            this.rdoMultiply.Location = new System.Drawing.Point(6, 109);
            this.rdoMultiply.Name = "rdoMultiply";
            this.rdoMultiply.Size = new System.Drawing.Size(145, 29);
            this.rdoMultiply.TabIndex = 2;
            this.rdoMultiply.TabStop = true;
            this.rdoMultiply.Text = "Multiply (*)";
            this.rdoMultiply.UseVisualStyleBackColor = true;
            // 
            // rdoSubtract
            // 
            this.rdoSubtract.AutoSize = true;
            this.rdoSubtract.Location = new System.Drawing.Point(6, 74);
            this.rdoSubtract.Name = "rdoSubtract";
            this.rdoSubtract.Size = new System.Drawing.Size(150, 29);
            this.rdoSubtract.TabIndex = 1;
            this.rdoSubtract.TabStop = true;
            this.rdoSubtract.Text = "Subtract (-)";
            this.rdoSubtract.UseVisualStyleBackColor = true;
            // 
            // rdoAdd
            // 
            this.rdoAdd.AutoSize = true;
            this.rdoAdd.Checked = true;
            this.rdoAdd.Location = new System.Drawing.Point(6, 49);
            this.rdoAdd.Name = "rdoAdd";
            this.rdoAdd.Size = new System.Drawing.Size(113, 29);
            this.rdoAdd.TabIndex = 0;
            this.rdoAdd.TabStop = true;
            this.rdoAdd.Text = "Add (+)";
            this.rdoAdd.UseVisualStyleBackColor = true;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(51, 434);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(144, 43);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // chkVerbose
            // 
            this.chkVerbose.AutoSize = true;
            this.chkVerbose.Checked = true;
            this.chkVerbose.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkVerbose.Location = new System.Drawing.Point(424, 434);
            this.chkVerbose.Name = "chkVerbose";
            this.chkVerbose.Size = new System.Drawing.Size(372, 29);
            this.chkVerbose.TabIndex = 4;
            this.chkVerbose.Text = "Check to to turn on Verbose Mode";
            this.chkVerbose.UseVisualStyleBackColor = true;
            // 
            // lblMessage
            // 
            this.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMessage.Location = new System.Drawing.Point(376, 519);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(307, 47);
            this.lblMessage.TabIndex = 5;
            this.lblMessage.Text = "\"   \"";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(51, 594);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(99, 42);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(169, 594);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(98, 42);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmRadioStar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1070, 679);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.chkVerbose);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.grpOperations);
            this.Controls.Add(this.txtRightOperand);
            this.Controls.Add(this.lblRIghtOperand);
            this.Controls.Add(this.txtLeftOperand);
            this.Controls.Add(this.lblLeftOperand);
            this.KeyPreview = true;
            this.Name = "frmRadioStar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Radio Buttons In Action";
            this.grpOperations.ResumeLayout(false);
            this.grpOperations.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void lblLeftOperand_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label lblLeftOperand;
        private System.Windows.Forms.TextBox txtLeftOperand;
        private System.Windows.Forms.Label lblRIghtOperand;
        private System.Windows.Forms.TextBox txtRightOperand;
        private System.Windows.Forms.GroupBox grpOperations;
        private System.Windows.Forms.RadioButton rdoAdd;
        private System.Windows.Forms.RadioButton rdoModulus;
        private System.Windows.Forms.RadioButton rdoDivide;
        private System.Windows.Forms.RadioButton rdoMultiply;
        private System.Windows.Forms.RadioButton rdoSubtract;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.CheckBox chkVerbose;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}

