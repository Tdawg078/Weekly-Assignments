﻿using System;

namespace CollectionPerryProject
{
    partial class frmCollections
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNumberInput = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnsShowStats = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblNumberInput = new System.Windows.Forms.Label();
            this.txtCollectionDisplay = new System.Windows.Forms.TextBox();
            this.txtStatsBox = new System.Windows.Forms.TextBox();
            this.CollectionDisplay1st = new System.Windows.Forms.ListBox();
            this.rtbStats = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // txtNumberInput
            // 
            this.txtNumberInput.Location = new System.Drawing.Point(228, 41);
            this.txtNumberInput.Name = "txtNumberInput";
            this.txtNumberInput.Size = new System.Drawing.Size(200, 31);
            this.txtNumberInput.TabIndex = 0;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(12, 390);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(237, 44);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Add to Collection";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnsShowStats
            // 
            this.btnsShowStats.Location = new System.Drawing.Point(255, 390);
            this.btnsShowStats.Name = "btnsShowStats";
            this.btnsShowStats.Size = new System.Drawing.Size(238, 51);
            this.btnsShowStats.TabIndex = 2;
            this.btnsShowStats.Text = "Show Statistics";
            this.btnsShowStats.UseVisualStyleBackColor = true;
            this.btnsShowStats.Click += new System.EventHandler(this.btnShowStats_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(12, 468);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(172, 51);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click_1);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(199, 468);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(172, 51);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click_1);
            // 
            // lblNumberInput
            // 
            this.lblNumberInput.AutoSize = true;
            this.lblNumberInput.Location = new System.Drawing.Point(28, 47);
            this.lblNumberInput.Name = "lblNumberInput";
            this.lblNumberInput.Size = new System.Drawing.Size(188, 25);
            this.lblNumberInput.TabIndex = 5;
            this.lblNumberInput.Text = "\"Enter a Number: \"";
            // 
            // txtCollectionDisplay
            // 
            this.txtCollectionDisplay.Location = new System.Drawing.Point(228, 98);
            this.txtCollectionDisplay.Name = "txtCollectionDisplay";
            this.txtCollectionDisplay.Size = new System.Drawing.Size(200, 31);
            this.txtCollectionDisplay.TabIndex = 6;
            // 
            // txtStatsBox
            // 
            this.txtStatsBox.Location = new System.Drawing.Point(228, 157);
            this.txtStatsBox.Name = "txtStatsBox";
            this.txtStatsBox.Size = new System.Drawing.Size(500, 31);
            this.txtStatsBox.TabIndex = 7;
            this.txtStatsBox.TextChanged += new System.EventHandler(this.txtStatsBox_TextChanged);
            // 
            // CollectionDisplay1st
            // 
            this.CollectionDisplay1st.BackColor = System.Drawing.SystemColors.Highlight;
            this.CollectionDisplay1st.FormattingEnabled = true;
            this.CollectionDisplay1st.ItemHeight = 25;
            this.CollectionDisplay1st.Location = new System.Drawing.Point(33, 223);
            this.CollectionDisplay1st.Name = "CollectionDisplay1st";
            this.CollectionDisplay1st.Size = new System.Drawing.Size(216, 79);
            this.CollectionDisplay1st.TabIndex = 8;
            // 
            // rtbStats
            // 
            this.rtbStats.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.rtbStats.Location = new System.Drawing.Point(328, 223);
            this.rtbStats.Name = "rtbStats";
            this.rtbStats.Size = new System.Drawing.Size(100, 96);
            this.rtbStats.TabIndex = 9;
            this.rtbStats.Text = "";
            // 
            // frmCollections
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(983, 699);
            this.Controls.Add(this.rtbStats);
            this.Controls.Add(this.CollectionDisplay1st);
            this.Controls.Add(this.txtStatsBox);
            this.Controls.Add(this.txtCollectionDisplay);
            this.Controls.Add(this.lblNumberInput);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnsShowStats);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtNumberInput);
            this.Name = "frmCollections";
            this.Text = "CollectionLab";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void btnsShowStats_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.TextBox txtNumberInput;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnsShowStats;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblNumberInput;
        private System.Windows.Forms.TextBox txtCollectionDisplay;
        private System.Windows.Forms.TextBox txtStatsBox;
        private System.Windows.Forms.ListBox CollectionDisplay1st;
        private System.Windows.Forms.RichTextBox rtbStats;
    }
}

