﻿namespace CollectionPerryProject
{
    public interface IfrmCollections
    {
        int MAX_ELEMENTS { get; }
        int MAX_VALUE { get; }
        int MIN_VALUE { get; }
    }
}