﻿/* 
   Your Name:
   Class Information:
   Due Date:
*/
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CollectionPerryProject
{
    public partial class frmCollections : Form
    {
        // Constants
        private const int MIN_VALUE = -1217;
        private const int MAX_VALUE = 1217;
        private const int MAX_COUNT = 17;

        // List to store numbers
        private List<int> numbers = new List<int>();

        public frmCollections()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.KeyPreview = true;
            this.KeyDown += new KeyEventHandler(frmCollections_KeyDown); // Escape key to exit
        }

        // 📌 Add Number Button Click
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidateInput(out int number))
                {
                    if (numbers.Count >= MAX_COUNT)
                    {
                        txtStatsBox.Text = "❌ Error: Collection is full.";
                    }
                    else
                    {
                        numbers.Add(number);
                        txtStatsBox.Text = "✅ Number added successfully.";
                    }
                    txtNumberInput.Clear();
                    txtNumberInput.Focus();
                }
            }
            catch (Exception ex)
            {
                txtStatsBox.Text = "🚨 Unexpected error: " + ex.Message;
            }
        }

        // 📌 Validate Input
        private bool ValidateInput(out int number)
        {
            number = 0;
            try
            {
                if (!int.TryParse(txtNumberInput.Text, out number))
                {
                    txtStatsBox.Text = "❌ Error: Invalid input. Please enter an integer.";
                    txtNumberInput.Clear();
                    txtNumberInput.Focus();
                    return false;
                }
                if (number < MIN_VALUE || number > MAX_VALUE)
                {
                    txtStatsBox.Text = $"❌ Error: Number must be between {MIN_VALUE} and {MAX_VALUE}.";
                    txtNumberInput.Clear();
                    txtNumberInput.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                txtStatsBox.Text = "🚨 Unexpected error: " + ex.Message;
                return false;
            }
        }

        // 📌 Show Statistics Button Click
        private void btnShowStats_Click(object sender, EventArgs e)
        {
            try
            {
                if (numbers.Count == 0)
                {
                    txtStatsBox.Text = "⚠️ Error: Collection is empty.";
                    return;
                }

                // Calculate statistics
                int sum = 0, min = numbers[0], max = numbers[0];
                foreach (int num in numbers)
                {
                    sum += num;
                    if (num < min) min = num;
                    if (num > max) max = num;
                }
                double average = (double)sum / numbers.Count;

                // Display numbers in ListBox
                CollectionDisplay1st.Items.Clear();
                foreach (int num in numbers)
                    CollectionDisplay1st.Items.Add(num);

                // Display statistics
                txtStatsBox.Text = $"📊 Statistics:\n" +
                                   $"📌 High Number: {max}\n" +
                                   $"📌 Low Number: {min}\n" +
                                   $"📌 Average: {average:F4}\n" +
                                   $"📌 Count: {numbers.Count}";
            }
            catch (Exception ex)
            {
                txtStatsBox.Text = "🚨 Unexpected error: " + ex.Message;
            }
        }

        // 📌 Reset Button Click
        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                numbers.Clear();
                CollectionDisplay1st.Items.Clear();
                txtStatsBox.Text = "🔄 Collection has been cleared.";
                txtNumberInput.Clear();
                txtNumberInput.Focus();
            }
            catch (Exception ex)
            {
                txtStatsBox.Text = "🚨 Unexpected error: " + ex.Message;
            }
        }

        // 📌 Exit Button Click
        private void btnExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                txtStatsBox.Text = "🚨 Unexpected error: " + ex.Message;
            }
        }

        // 📌 Handle Escape Key to Exit
        private void frmCollections_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                btnExit.PerformClick();
        }

        private void txtStatsBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReset_Click_1(object sender, EventArgs e)
        {
           
        {
            try
            {
                numbers.Clear(); // Clears the list
                CollectionDisplay1st.Items.Clear(); // Clears the ListBox
                txtStatsBox.Text = "🔄 Collection has been cleared."; // Update status
                txtNumberInput.Clear(); // Clears input field
                txtNumberInput.Focus(); // Focuses back on input field
            }
            catch (Exception ex)
            {
                txtStatsBox.Text = "🚨 Unexpected error: " + ex.Message;
            }
        }

        }
        
           

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                txtStatsBox.Text = "🚨 Unexpected error: " + ex.Message;
            }
        }

    }
}
}





