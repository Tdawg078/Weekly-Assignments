﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Sec3LabExamPerryProject
{
    public partial class Decoder : Form
    {
        private Dictionary<char, char> cipherMap;
        private Dictionary<char, char> reverseCipherMap;
        private int plainToCipherCount = 0;
        private int cipherToPlainCount = 0;

        public Decoder()
        {
            InitializeComponent();
            InitializeCipher();
            SetTabOrder();
            this.KeyPreview = true;
            this.KeyDown += new KeyEventHandler(Form1_KeyDown);
        }

        private void InitializeCipher()
        {
            cipherMap = new Dictionary<char, char>
            {
                {'A', 'R'}, {'B', 'S'}, {'C', 'N'}, {'D', 'E'}, {'E', 'P'},
                {'F', 'H'}, {'G', 'C'}, {'H', 'A'}, {'I', 'T'}, {'J', 'I'},
                {'K', 'M'}, {'L', 'G'}, {'M', 'L'}, {'N', 'X'}, {'O', 'W'},
                {'P', 'V'}, {'Q', 'F'}, {'R', 'U'}, {'S', 'J'}, {'T', 'Z'},
                {'U', 'K'}, {'V', 'O'}, {'W', 'B'}, {'X', 'Y'}, {'Y', 'D'},
                {'Z', 'Q'}
            };

            reverseCipherMap = new Dictionary<char, char>();
            foreach (var pair in cipherMap)
            {
                reverseCipherMap[pair.Value] = pair.Key;
            }
        }

        private void SetTabOrder()
        {
            txtInput.TabIndex = 0;
            btnConvert.TabIndex = 1;
            btnReset.TabIndex = 2;
            btnExit.TabIndex = 3;
        }

        private string ConvertText(string input, bool toCipher)
        {
            Dictionary<char, char> map = toCipher ? cipherMap : reverseCipherMap;
            char[] result = new char[input.Length];

            for (int i = 0; i < input.Length; i++)
            {
                char c = char.ToUpper(input[i]);
                result[i] = map.ContainsKey(c) ? map[c] : c;
            }
            return new string(result);
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            string inputText = txtInput.Text.Trim();
            List<string> errors = new List<string>();

            if (string.IsNullOrEmpty(inputText))
                errors.Add("Input cannot be empty.");

            if (!rdoEncode.Checked && !rdoDecode.Checked)
                errors.Add("Please select an encoding option.");

            if (errors.Count > 0)
            {
                MessageBox.Show(string.Join("\n", errors), "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool toCipher = rdoEncode.Checked;
            txtOutput.Text = ConvertText(inputText, toCipher);

            if (toCipher)
                plainToCipherCount++;
            else
                cipherToPlainCount++;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtInput.Clear();
            txtOutput.Clear();
            rdoEncode.Checked = false;
            rdoDecode.Checked = false;
            txtInput.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Total Messages Converted:\n" +
                            $"Plain to Cipher: {plainToCipherCount}\n" +
                            $"Cipher to Plain: {cipherToPlainCount}",
                            "Conversion Summary", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnConvert.PerformClick();
                e.SuppressKeyPress = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                btnExit.PerformClick();
                e.SuppressKeyPress = true;
            }
        }
    }
}

