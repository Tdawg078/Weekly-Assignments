﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project5Perry
{
    public partial class frmChoices : Form
    {
        public frmChoices()
        {
            InitializeComponent();
        }

        private void frmChoices_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            
        {
            this.Close();
        }

    }

        private void btnClear_Click(object sender, EventArgs e)
        {
            
        {
            txtLeftNumber.Text = "";
            txtRightNumber.Text = "";
            txtCheckNumber.Text = "";
            lblMessage.Text = "";
        }

    }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            
        {
            // Validate input
            if (!int.TryParse(txtLeftNumber.Text, out int leftNum) ||
                !int.TryParse(txtRightNumber.Text, out int rightNum) ||
                !int.TryParse(txtCheckNumber.Text, out int checkNum))
            {
                lblMessage.Text = "Please enter valid numbers.";
                return;
            }

            // Check range conditions
            if (checkNum < leftNum)
            {
                lblMessage.Text = $"The number {checkNum} is less than the lower range {leftNum}.";
            }
            else if (checkNum > rightNum)
            {
                lblMessage.Text = $"The number {checkNum} is greater than the upper range {rightNum}.";
            }
            else if (checkNum == leftNum)
            {
                lblMessage.Text = $"The number {checkNum} is equal to the lower range {leftNum}.";
            }
            else if (checkNum == rightNum)
            {
                lblMessage.Text = $"The number {checkNum} is equal to the upper range {rightNum}.";
            }
            else
            {
                lblMessage.Text = $"The number {checkNum} is within the range {leftNum} - {rightNum}.";
            }

            // Clear and focus check number textbox
            txtCheckNumber.Text = "";
            txtCheckNumber.Focus();
        }

    }
}
}
