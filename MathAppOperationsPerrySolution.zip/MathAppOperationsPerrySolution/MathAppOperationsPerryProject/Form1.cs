﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MathAppOperationsPerryProject
{
    public partial class Form1: Form
    {
        private object min;
        private object max;

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnShowFibonacci(object sender, EventArgs e)
        {
            
        {
            // Show single input field for Fibonacci
            txtOperand1.Visible = false;
            txtOperand2.Visible = false;
            txtSingleOperand.Visible = true;

            // Enable the Fibonacci DO button
            

            // Disable other DO buttons
            btnDoModulus.Enabled = false;
            btnDoFactorial.Enabled = false;

            // Set focus to the input field
            txtSingleOperand.Focus();

            // Update message area
            lblMessage.Text = "Enter a number and press DO Fibonacci.";
        }

        }

        

        

        private void BtnDoFibonacci (object sender, EventArgs e)

        {
            
        {
            lblMessage.Text = ""; // Clear message area
            if (!ValidateInput(txtSingleOperand.Text, out int num))
                return;

            if (num < 0)
            {
                lblMessage.Text = "Error: Fibonacci sequence cannot be calculated for negative numbers.";
                return;
            }

            if (num > 45)
            {
                lblMessage.Text = "Error: Fibonacci calculations are limited to values ≤ 45.";
                return;
            }

            if (num == 0)
            {
                lblMessage.Text = "Fibonacci(0) = 0";
                return;
            }

            if (num == 1)
            {
                lblMessage.Text = "Fibonacci(1) = 1";
                return;
            }

            int prev = 0, curr = 1, next;
            for (int i = 2; i <= num; i++)
            {
                next = prev + curr;
                prev = curr;
                curr = next;
            }

            lblMessage.Text = $"Fibonacci({num}) = {curr}";
        }

        }

        private bool ValidateInput(string text, out int num)
        {
            throw new NotImplementedException();
        }



        private void BtnDoFactorial_Click(object sender, EventArgs e)
        {
            
        {
            lblMessage.Text = ""; // Clear message area
            if (!ValidateInput(txtSingleOperand.Text, out int num))
                return;

            if (num < 0)
            {
                lblMessage.Text = "Error: Factorial cannot be calculated for negative numbers.";
                return;
            }

            if (num > 15)
            {
                lblMessage.Text = "Error: Factorial calculations are limited to values ≤ 15.";
                return;
            }

            int result = 1;
            for (int i = 1; i <= num; i++)
            {
                result *= i;
            }

            lblMessage.Text = $"The answer to {num}! is {result}.";
        }

        }
        
        
        
            
               
                    
        private void BtnDoModulus_Click(object sender, EventArgs e)
        {
            
        {
            lblMessage.Text = ""; // Clear message area
                if (!ValidateInput(txtOperand1.Text, txtOperand2.Text, out int num1, out int num2))
                return;

            if (num2 == 0)
            {
                lblMessage.Text = "Error: Division by zero is not allowed.";
                return;
            }

            int quotient = 0;
            int remainder = num1;

            // Subtract num2 from num1 repeatedly until remainder is less than num2
            while (remainder >= num2)
            {
                remainder -= num2;
                quotient++;
            }

            lblMessage.Text = $"{num1} divided by {num2} is {quotient} with a remainder of {remainder}.";
        }

        }

        private bool ValidateInput(string text1, string text2, out int num1, out int num2)
        {
            throw new NotImplementedException();
        }

        private void BtnShowModulus_Click(object sender, EventArgs e)
        {
            
        {
            // Show modulus input fields
            txtOperand1.Visible = true;
            txtOperand2.Visible = true;
            txtSingleOperand.Visible = false;

            // Enable the Modulus DO button
            btnDoModulus.Enabled = true;

            // Disable other DO buttons
            btnDoFactorial.Enabled = false;
            

            // Set focus to the first input field
            txtOperand1.Focus();

            // Update message area
            lblMessage.Text = "Enter two numbers and press DO Modulus.";
        }

        }    

            


        

        private void BtnShowFactorial_Click(object sender, EventArgs e)
        {
            
        {
            // Show single input field for Factorial
            txtOperand1.Visible = false;
            txtOperand2.Visible = false;
            txtSingleOperand.Visible = true;

            // Enable the Factorial DO button
            btnDoFactorial.Enabled = true;

            // Disable other DO buttons
            btnDoModulus.Enabled = false;
            

            // Set focus to the input field
            txtSingleOperand.Focus();

            // Update message area
            lblMessage.Text = "Enter a number and press DO Factorial.";
        }

        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            
        {
            lblMessage.Text = "Message area cleared.";
        }

        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
           
        {
            DialogResult result = MessageBox.Show("Thank you for using the application!",
                                                  "Goodbye",
                                                  MessageBoxButtons.OK,
                                                  MessageBoxIcon.Information);

            if (result == DialogResult.OK)
            {
                Application.Exit();
            }
        }

    }

        private void lblMessage_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "Enter the operands and press DO [operation].";
            lblMessage.Text += "Error: Input cannot be empty.\n";
            lblMessage.Text += "Error: Input must be an integer.\n";
            lblMessage.Text += $"Error: Input must be between {min} and {max}.\n";

        }
    }
}


