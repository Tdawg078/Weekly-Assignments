﻿using System;

namespace MathAppOperationsPerryProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtOperand1 = new System.Windows.Forms.TextBox();
            this.txtOperand2 = new System.Windows.Forms.TextBox();
            this.txtSingleOperand = new System.Windows.Forms.TextBox();
            this.btnShowModulus = new System.Windows.Forms.Button();
            this.btnDoModulus = new System.Windows.Forms.Button();
            this.btnShowFactorial = new System.Windows.Forms.Button();
            this.btnDoFactorial = new System.Windows.Forms.Button();
            this.btnShowFibonacci = new System.Windows.Forms.Button();
            this.btnDoFibonnaci = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtOperand1
            // 
            this.txtOperand1.BackColor = System.Drawing.Color.Red;
            this.txtOperand1.Font = new System.Drawing.Font("Courier New", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOperand1.Location = new System.Drawing.Point(37, 36);
            this.txtOperand1.Name = "txtOperand1";
            this.txtOperand1.Size = new System.Drawing.Size(100, 49);
            this.txtOperand1.TabIndex = 1;
            // 
            // txtOperand2
            // 
            this.txtOperand2.BackColor = System.Drawing.SystemColors.Highlight;
            this.txtOperand2.Font = new System.Drawing.Font("Courier New", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOperand2.Location = new System.Drawing.Point(37, 155);
            this.txtOperand2.Name = "txtOperand2";
            this.txtOperand2.Size = new System.Drawing.Size(100, 49);
            this.txtOperand2.TabIndex = 3;
            // 
            // txtSingleOperand
            // 
            this.txtSingleOperand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.txtSingleOperand.Font = new System.Drawing.Font("Courier New", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSingleOperand.Location = new System.Drawing.Point(37, 266);
            this.txtSingleOperand.Name = "txtSingleOperand";
            this.txtSingleOperand.Size = new System.Drawing.Size(100, 49);
            this.txtSingleOperand.TabIndex = 4;
            // 
            // btnShowModulus
            // 
            this.btnShowModulus.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowModulus.Location = new System.Drawing.Point(24, 398);
            this.btnShowModulus.Name = "btnShowModulus";
            this.btnShowModulus.Size = new System.Drawing.Size(224, 55);
            this.btnShowModulus.TabIndex = 5;
            this.btnShowModulus.Text = "ShowModulus";
            this.btnShowModulus.UseVisualStyleBackColor = true;
            this.btnShowModulus.Click += new System.EventHandler(this.BtnShowModulus_Click);
            // 
            // btnDoModulus
            // 
            this.btnDoModulus.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoModulus.Location = new System.Drawing.Point(264, 402);
            this.btnDoModulus.Name = "btnDoModulus";
            this.btnDoModulus.Size = new System.Drawing.Size(218, 51);
            this.btnDoModulus.TabIndex = 14;
            this.btnDoModulus.Text = "DoModulus";
            this.btnDoModulus.UseVisualStyleBackColor = true;
            this.btnDoModulus.Click += new System.EventHandler(this.BtnDoModulus_Click);
            // 
            // btnShowFactorial
            // 
            this.btnShowFactorial.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowFactorial.Location = new System.Drawing.Point(488, 403);
            this.btnShowFactorial.Name = "btnShowFactorial";
            this.btnShowFactorial.Size = new System.Drawing.Size(265, 50);
            this.btnShowFactorial.TabIndex = 15;
            this.btnShowFactorial.Text = "ShowFactorial";
            this.btnShowFactorial.UseVisualStyleBackColor = true;
            this.btnShowFactorial.Click += new System.EventHandler(this.BtnShowFactorial_Click);
            // 
            // btnDoFactorial
            // 
            this.btnDoFactorial.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoFactorial.Location = new System.Drawing.Point(24, 479);
            this.btnDoFactorial.Name = "btnDoFactorial";
            this.btnDoFactorial.Size = new System.Drawing.Size(212, 51);
            this.btnDoFactorial.TabIndex = 16;
            this.btnDoFactorial.Text = "DoFactorial";
            this.btnDoFactorial.UseCompatibleTextRendering = true;
            this.btnDoFactorial.UseVisualStyleBackColor = true;
            this.btnDoFactorial.Click += new System.EventHandler(this.BtnDoFactorial_Click);
            // 
            // btnShowFibonacci
            // 
            this.btnShowFibonacci.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowFibonacci.Location = new System.Drawing.Point(264, 479);
            this.btnShowFibonacci.Name = "btnShowFibonacci";
            this.btnShowFibonacci.Size = new System.Drawing.Size(270, 51);
            this.btnShowFibonacci.TabIndex = 17;
            this.btnShowFibonacci.Text = "ShowFibonacci";
            this.btnShowFibonacci.UseVisualStyleBackColor = true;
            this.btnShowFibonacci.Click += new System.EventHandler(this.BtnShowFibonacci);
            // 
            // btnDoFibonnaci
            // 
            this.btnDoFibonnaci.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoFibonnaci.Location = new System.Drawing.Point(549, 480);
            this.btnDoFibonnaci.Name = "btnDoFibonnaci";
            this.btnDoFibonnaci.Size = new System.Drawing.Size(253, 50);
            this.btnDoFibonnaci.TabIndex = 18;
            this.btnDoFibonnaci.Text = "DoFibonacci";
            this.btnDoFibonnaci.UseVisualStyleBackColor = true;
            this.btnDoFibonnaci.Click += new System.EventHandler(this.BtnDoFibonacci_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Yellow;
            this.btnClear.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(24, 573);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(139, 56);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnExit.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(200, 575);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(132, 54);
            this.btnExit.TabIndex = 20;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblMessage.Font = new System.Drawing.Font("Times New Roman", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(355, 636);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(81, 49);
            this.lblMessage.TabIndex = 21;
            this.lblMessage.Text = "\" \"";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMessage.Click += new System.EventHandler(this.lblMessage_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(941, 745);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDoFibonnaci);
            this.Controls.Add(this.btnShowFibonacci);
            this.Controls.Add(this.btnDoFactorial);
            this.Controls.Add(this.btnShowFactorial);
            this.Controls.Add(this.btnDoModulus);
            this.Controls.Add(this.btnShowModulus);
            this.Controls.Add(this.txtSingleOperand);
            this.Controls.Add(this.txtOperand2);
            this.Controls.Add(this.txtOperand1);
            this.Name = "Form1";
            this.Text = "Perry Operations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void BtnDoFibonacci_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.TextBox txtOperand1;
        private System.Windows.Forms.TextBox txtOperand2;
        private System.Windows.Forms.TextBox txtSingleOperand;
        private System.Windows.Forms.Button btnShowModulus;
        private System.Windows.Forms.Button btnDoModulus;
        private System.Windows.Forms.Button btnShowFactorial;
        private System.Windows.Forms.Button btnDoFactorial;
        private System.Windows.Forms.Button btnShowFibonacci;
        private System.Windows.Forms.Button btnDoFibonnaci;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblMessage;
    }
}

